# CSE3033_Project3_2023

### Operating Systems

> Muhammed Talha Karagül - 150120055
>
> Kadir Bat - 150120012
>
> Feyzullah Asıllıoğlu - 150121021

##### To Compile Code:

> gcc project3.c -o project3.out -lm -pthread

To Run Code:

> time ./project3.out `<startOfTheRange>` `<endOfTheRange>` `<threadNumber>` `<methodNumber>`
